#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this); // R�cup le formulaire de Qt Designer

    // Initialiser les �tiquettes de gauche avec les caract�ristiques du h�ros et �ventuellement du monstre
    // Cette partie est juste l� pour afficher quelque chose pour le moment.
    labelHeros = ui->labelHeros;
    labelMonstre = ui->labelMonstre;

    Personnage monstre("Gros vilain pas beau");
    std::ostringstream profilMonstre;
    profilMonstre << monstre;
    labelMonstre->setText(QString::fromStdString(profilMonstre.str()));

    Personnage heros("Luc");
    std::ostringstream profilHeros;
    profilHeros << heros;
    labelHeros->setText(QString::fromStdString(profilHeros.str()));
    ///////////////////////////////////////////////////////////////////////////////////////////////////////

    // Initialisation des boutons, des zones texte, etc.
    zoneTexte = ui->zoneTexte;


    boutonObjet = ui->boutonObjet;
    boutonCompetence = ui->boutonCompetence;
    boutonJournal = ui->boutonJournal;
    boutonProfil = ui->boutonProfil;
    boutonAttaquer = ui->boutonAttaquer;

    boutonObjet->setText("Objet");
    boutonCompetence->setText("Comp�tences");
    boutonJournal->setText("Journal");
    boutonProfil->setText("Profil");
    boutonAttaquer->setText("Attaquer");


    // Gestion des clicks de bouton et autres �v�nements
    QObject::connect(boutonObjet , SIGNAL (clicked()) , this , SLOT (tester()));
    QObject::connect(boutonCompetence , SIGNAL (clicked()) , this , SLOT (tester()));
    QObject::connect(boutonJournal , SIGNAL (clicked()) , this , SLOT (tester()));
    QObject::connect(boutonProfil , SIGNAL (clicked()) , this , SLOT (tester()));
    QObject::connect(boutonAttaquer , SIGNAL (clicked()) , this , SLOT (lancerDes()));

    QObject::connect(ui->actionQuitter , SIGNAL (triggered()) , qApp , SLOT (quit()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::tester () {
    qDebug("Test");
}


// Voici le code � placer lorsque l'on veut jeter des d�s
void MainWindow::lancerDes (int nombreDeDes) {
    ModuleDes monDe (nombreDeDes , this);
    QObject::connect(&monDe , SIGNAL (resultats(QVector<int>)) , this , SLOT (afficherResultat(QVector<int>)));
    monDe.exec();
}

void MainWindow::afficherResultat (QVector<int> jets) {
    for (int i =0 ; i < jets.size() ; i++) {
        //zoneTexte->appendPlainText(QString::number(jets[i]));
        zoneTexte->load(QUrl("/home/francois/Documents/C++/siteDuZero/Qt/livre_design-build-desktop/texte.txt"));
    }
}

