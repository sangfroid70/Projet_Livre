#ifndef comb_point_h
#define comb_point_h

#include <iostream>
using namespace std;
#include "classesbase.h"

//ces fonctions sont hors des classes mais sont utilisées dans le main

int lancer_de();
rescombat combat(vous v,monstre m);
vous transcrire_sauvegarde_perso(int ppv, string aarme, int ddegats);

#endif
