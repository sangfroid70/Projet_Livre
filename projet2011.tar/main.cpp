#include <QtGui>
#include <iostream>
#include <fstream>
#include <stdlib.h>
using namespace std;
#include "classesbase.h"
#include "combat.h"


int main(int argc, char *argv[])
{
	
	srand(time(NULL));

    QApplication app(argc,argv);

	
	// OBJETS DE BASE

	// il y en a plusieurs types : les armes, les objets, les monstres...

	arme a1=arme();
	a1.changer_arme("Barre_de_fer",2);
	
	arme a2=arme();
	a2.changer_arme("Dague_de_Géant",3);
	
	arme a3=arme();
	a3.changer_arme("Balmung",4);
	
	arme a4=arme();
	a4.changer_arme("Bâton",1);
	
	arme b1=arme();
	b1.changer_arme("Crocs émoussés",1);
	
	arme b2=arme();
	b2.changer_arme("Crocs",2);
	
	arme b3=arme();
	b3.changer_arme("Bec",2);
	
	arme b4=arme();
	b4.changer_arme("Gourdin",2);
	
	arme b5=arme();
	b5.changer_arme("Poignard",3);
	
	arme b6=arme();
	b6.changer_arme("Griffes acérées",3);
	
	objet p=objet();
	p.changer_objet("Potion");
	
	objet o1=objet();
	o1.changer_objet("Corde");
	
	objet o2=objet();
	o2.changer_objet("Coupe_en_Or");
	
	objet o3=objet();
	o3.changer_objet("Miroir");
	
	objet o4=objet();
	o4.changer_objet("Antidote");
	
	objet o5=objet();
	o5.changer_objet("Croc_empoisonné");
	
	objet o6=objet();
	o6.changer_objet("Essence_nocturne");
	
	objet o7=objet();
	o7.changer_objet("Pierre_solaire");
	
	monstre m1=monstre();
	m1.changer_nom("Chat sauvage");
	m1.changer_descr("Un chat errant");
	m1.changer_pv(5);
	m1.changer_para_suiv("Allez au 30");
	
	monstre m2=monstre();
	m2.changer_nom("Jormungand");
	m2.changer_descr("Le Serpent-Monde, l'ennemi juré du dieu Thor");
	m2.changer_pv(40);
	m2.changer_arme_equipee(b2);
	m2.changer_para_suiv("Allez au 67");
	
	monstre m3=monstre();
	m3.changer_nom("Loup");
	m3.changer_descr("Un gros loup affamé");
	m3.changer_pv(20);
	m3.changer_arme_equipee(b2);
	m3.changer_para_suiv("Allez au 49");
	
	monstre m4=monstre();
	m4.changer_nom("Troll");
	m4.changer_descr("Il ne vous a pourtant rien fait...");
	m4.changer_pv(20);
	m4.changer_arme_equipee(b4);
	m4.changer_para_suiv("Allez au 49");
	
	monstre m5=monstre();
	m5.changer_nom("Döppleganger");
	m5.changer_descr("Le fameux voleur de poules de Gerd");
	m5.changer_pv(35);
	m5.changer_arme_equipee(b6);
	m5.changer_para_suiv("Allez au 47");
	
	monstre m6=monstre();
	m6.changer_nom("Lion de Pierre");
	m6.changer_descr("Le dernier spécimen de son espèce");
	m6.changer_pv(50);
	m6.changer_arme_equipee(b2);
	m6.changer_para_suiv("Allez au 69");
	
	monstre m7=monstre();
	m7.changer_nom("Vieux Worm");
	m7.changer_descr("Un Dragon qui n'est plus de première fraîcheur...");
	m7.changer_pv(25);
	m7.changer_arme_equipee(b1);
	m7.changer_para_suiv("Allez au 66");
	
	monstre m8=monstre();
	m8.changer_nom("Managarm");
	m8.changer_descr("Un loup descendant du chien Garm, gardien de Helheim");
	m8.changer_pv(35);
	m8.changer_arme_equipee(b2);
	m8.changer_para_suiv("Allez au 57");
	
	monstre m9=monstre();
	m9.changer_nom("Aigle Gardien");
	m9.changer_descr("L'un des gardiens de l'entrée de Helheim");
	m9.changer_pv(35);
	m9.changer_arme_equipee(b3);
	m9.changer_para_suiv("Allez au 72");
	
	monstre m10=monstre();
	m10.changer_nom("Garm Aveugle");
	m10.changer_descr("Garm aveuglé par l'Essence de Nott");
	m10.changer_pv(25);
	m10.changer_arme_equipee(b2);
	m10.changer_para_suiv("Allez au 83");
	
	monstre m11=monstre();
	m11.changer_nom("Garm");
	m11.changer_descr("Le terrible chien de garde de Helheim");
	m11.changer_pv(50);
	m11.changer_arme_equipee(b6);
	m11.changer_para_suiv("Allez au 83");
	
	monstre m12=monstre();
	m12.changer_nom("Loki");
	m12.changer_descr("Le fourbe, il a pas pu s'en empêcher !");
	m12.changer_pv(35);
	m12.changer_arme_equipee(b5);
	m12.changer_para_suiv("Allez au 100");
	
	
	// LES TABLEAUX //
	
	//chaque tableau contient des emplacements vides correspondants aux constructeurs de chaque classe ; parfois, les emplacements vides sont "remplis" par des objets/monstres/paragraphes/armes

	monstre* table_rencontres=new monstre[110]; //le tableau des monstres
	for (int i=0;i<110;i++) {table_rencontres[i]=monstre();}
	table_rencontres[8]=m1;
	table_rencontres[44]=m2;
	table_rencontres[26]=m3;
	table_rencontres[6]=m4;
	table_rencontres[43]=m5;
	table_rencontres[73]=m6;
	table_rencontres[75]=m7;
	table_rencontres[65]=m8;
	table_rencontres[77]=m9;
	table_rencontres[78]=m10;
	table_rencontres[94]=m11;
	table_rencontres[71]=m12;

	objet* table_item=new objet[110]; //le tableau des objets
	for (int i=0;i<110;i++) {table_item[i]=objet();}
	table_item[3]=o1;
	table_item[6]=o2;
	table_item[42]=o3;
	table_item[64]=o4;
	table_item[44]=o5;
	table_item[58]=o6;
	table_item[69]=o7;
	
	arme* armurerie=new arme[110]; // le tableau des armes
	for (int i=0;i<110;i++) {armurerie[i]=arme();}
	armurerie[3]=a1;
	armurerie[37]=a2;
	armurerie[66]=a3;
	armurerie[8]=a4;
	

	string* paragraphe=new string[110]; // le tableau des paragraphes
	for (int i=0;i<110;i++) {paragraphe[i]="rien";}
	paragraphe[0]="zero.txt";
	paragraphe[1]="un.txt";
	paragraphe[2]="deux.txt";
	paragraphe[3]="trois.txt";
	paragraphe[4]="quatre.txt";
	paragraphe[5]="cinq.txt";
	paragraphe[6]="six.txt";
	paragraphe[7]="sept.txt";
	paragraphe[8]="huit.txt";
	paragraphe[9]="neuf.txt";
	paragraphe[10]="dix.txt";
	paragraphe[11]="onze.txt";
	paragraphe[12]="douze.txt";
	paragraphe[13]="treize.txt";
	paragraphe[14]="quatorze.txt";
	paragraphe[15]="quinze.txt";
	paragraphe[16]="seize.txt";
	paragraphe[17]="dixsept.txt";
	paragraphe[18]="dixhuit.txt";
	paragraphe[19]="dixneuf.txt";
	paragraphe[20]="vingt.txt";
	paragraphe[21]="vingtetun.txt";
	paragraphe[22]="vingtdeux.txt";
	paragraphe[23]="vingttrois.txt";
	paragraphe[24]="vingtquatre.txt";
	paragraphe[25]="vingtcinq.txt";
	paragraphe[26]="vingtsix.txt";
	paragraphe[27]="vingtsept.txt";
	paragraphe[28]="vingthuit.txt";
	paragraphe[29]="vingtneuf.txt";
	paragraphe[30]="trente.txt";
	paragraphe[31]="trenteetun.txt";
	paragraphe[32]="trentedeux.txt";
	paragraphe[33]="trentetrois.txt";
	paragraphe[34]="trentequatre.txt";
	paragraphe[35]="trentecinq.txt";
	paragraphe[36]="trentesix.txt";
	paragraphe[37]="trentesept.txt";
	paragraphe[38]="trentehuit.txt";
	paragraphe[39]="trenteneuf.txt";
	paragraphe[40]="quarante.txt";
	paragraphe[41]="quaranteetun.txt";
	paragraphe[42]="quarantedeux.txt";
	paragraphe[43]="quarantetrois.txt";
	paragraphe[44]="quarantequatre.txt";
	paragraphe[45]="quarantecinq.txt";
	paragraphe[46]="quarantesix.txt";
	paragraphe[47]="quarantesept.txt";
	paragraphe[48]="quarantehuit.txt";
	paragraphe[49]="quaranteneuf.txt";
	paragraphe[50]="cinquante.txt";
	paragraphe[51]="cinquanteetun.txt";
	paragraphe[52]="cinquantedeux.txt";
	paragraphe[53]="cinquantetrois.txt";
	paragraphe[54]="cinquantequatre.txt";
	paragraphe[55]="cinquantecinq.txt";
	paragraphe[56]="cinquantesix.txt";
	paragraphe[57]="cinquantesept.txt";
	paragraphe[58]="cinquantehuit.txt";
	paragraphe[59]="cinquanteneuf.txt";
	paragraphe[60]="soixante.txt";
	paragraphe[61]="soixanteetun.txt";
	paragraphe[62]="soixantedeux.txt";
	paragraphe[63]="soixantetrois.txt";
	paragraphe[64]="soixantequatre.txt";
	paragraphe[65]="soixantecinq.txt";
	paragraphe[66]="soixantesix.txt";
	paragraphe[67]="soixantesept.txt";
	paragraphe[68]="soixantehuit.txt";
	paragraphe[69]="soixanteneuf.txt";
	paragraphe[70]="soixantedix.txt";
	paragraphe[71]="soixanteetonze.txt";
	paragraphe[72]="soixantedouze.txt";
	paragraphe[73]="soixantetreize.txt";
	paragraphe[74]="soixantequatorze.txt";
	paragraphe[75]="soixantequinze.txt";
	paragraphe[76]="soixanteseize.txt";
	paragraphe[77]="soixantedixsept.txt";
	paragraphe[78]="soixantedixhuit.txt";
	paragraphe[79]="soixantedixneuf.txt";
	paragraphe[80]="quatrevingt.txt";
	paragraphe[81]="quatrevingtun.txt";
	paragraphe[82]="quatrevingtdeux.txt";
	paragraphe[83]="quatrevingttrois.txt";
	paragraphe[84]="quatrevingtquatre.txt";
	paragraphe[85]="quatrevingtcinq.txt";
	paragraphe[86]="quatrevingtsix.txt";
	paragraphe[87]="quatrevingtsept.txt";
	paragraphe[88]="quatrevingthuit.txt";
	paragraphe[89]="quatrevingtneuf.txt";
	paragraphe[90]="quatrevingtdix.txt";
	paragraphe[92]="quatrevingtdouze.txt";
	paragraphe[94]="quatrevingtquatorze.txt";
	paragraphe[96]="quatrevingtseize.txt";
	paragraphe[100]="cent.txt";
	paragraphe[101]="centun.txt";



	// REGLES DU JEU
	
	
	AfficherTexte* aff=new AfficherTexte();
	AfficherRegles* regl=new AfficherRegles();
	aff=regl->ouvrirDialogue();
	if (aff != NULL)
	{aff->show();
	app.exec();
	aff->close();}


 


	// MOTEUR DE JEU

	 
	 vous v=vous(); //création d'une Feuille de Personnage et d'un Journal
	 journal j=journal();
	 int para=0;
	 
	 
	//menu de départ
	 int chargerpartie=-1;
	 int charger=-1;

	 cout<<endl;
	 cout<<"	DEBUT DU JEU	"<<endl;
	 cout<<endl;

	 AfficherMenu* am1=new AfficherMenu();
	 charger=am1->ouvrirMenuDepart();
	 
	 if (charger==1)
	 { 
		 AfficherMenu* am2=new AfficherMenu();
		 chargerpartie=am2->choisiremplacement();

	 if (chargerpartie==1)
	  {
		  
		  
		ifstream fichiercharger("sauvegarde1.txt", ios::in);

        if(fichiercharger)
        {
                int pararecup;
                int pvrecup;
                string armerecup;
                int degatsrecup;
                
                int nbobjetsrecup;
                string nomobjetrecup;
                objet objetrecup=objet();
                
                int nbentreesrecup;
                string nomentreesrecup;
                int nompararecup;

                fichiercharger >> pararecup >> pvrecup >> armerecup >> degatsrecup >> nbobjetsrecup;  //on lit jusqu'à l'espace et on stocke ce qui est lu dans la variable indiquée

				para=pararecup;
				v=transcrire_sauvegarde_perso(pvrecup,armerecup,degatsrecup);

				for (int i=0;i<nbobjetsrecup;i++) { fichiercharger >> nomobjetrecup;
													objetrecup.changer_objet(nomobjetrecup);
													v.ajout_objet(objetrecup); }
					
				fichiercharger >> nbentreesrecup;
												
				for (int k=0;k<nbentreesrecup;k++) { fichiercharger >> nomentreesrecup;
													 fichiercharger >> nompararecup;
													 j.ajout_descr_para(nomentreesrecup, nompararecup); }


                fichiercharger.close();
          
        }
        else
               { cout << "Impossible d'ouvrir le fichier !" << endl;}
               
               
	 }

	 if (chargerpartie==2)
	  {  
		  
		ifstream fichiercharger("sauvegarde2.txt", ios::in);

        if(fichiercharger)
        {
                int pararecup;
                int pvrecup;
                string armerecup;
                int degatsrecup;
                
                int nbobjetsrecup;
                string nomobjetrecup;
                objet objetrecup=objet();
                
                int nbentreesrecup;
                string nomentreesrecup;
                int nompararecup;

                fichiercharger >> pararecup >> pvrecup >> armerecup >> degatsrecup >> nbobjetsrecup;  //on lit jusqu'à l'espace et on stocke ce qui est lu dans la variable indiquée

				para=pararecup;
				v=transcrire_sauvegarde_perso(pvrecup,armerecup,degatsrecup);

				for (int i=0;i<nbobjetsrecup;i++) { fichiercharger >> nomobjetrecup;
													objetrecup.changer_objet(nomobjetrecup);
													v.ajout_objet(objetrecup); }
					
				fichiercharger >> nbentreesrecup;
												
				for (int k=0;k<nbentreesrecup;k++) { fichiercharger >> nomentreesrecup;
													 fichiercharger >> nompararecup;
													 j.ajout_descr_para(nomentreesrecup, nompararecup); }


                fichiercharger.close();
          
        }
        else
               { cout << "Impossible d'ouvrir le fichier !" << endl;}
               
               
	 }
	 
	 
	if (chargerpartie==3)
	  {  
		  
		ifstream fichiercharger("sauvegarde3.txt", ios::in);

        if(fichiercharger)
        {
                int pararecup;
                int pvrecup;
                string armerecup;
                int degatsrecup;
                
                int nbobjetsrecup;
                string nomobjetrecup;
                objet objetrecup=objet();
                
                int nbentreesrecup;
                string nomentreesrecup;
                int nompararecup;

                fichiercharger >> pararecup >> pvrecup >> armerecup >> degatsrecup >> nbobjetsrecup;  //on lit jusqu'à l'espace et on stocke ce qui est lu dans la variable indiquée

				para=pararecup;
				v=transcrire_sauvegarde_perso(pvrecup,armerecup,degatsrecup);

				for (int i=0;i<nbobjetsrecup;i++) { fichiercharger >> nomobjetrecup;
													objetrecup.changer_objet(nomobjetrecup);
													v.ajout_objet(objetrecup); }
					
				fichiercharger >> nbentreesrecup;
												
				for (int k=0;k<nbentreesrecup;k++) { fichiercharger >> nomentreesrecup;
													 fichiercharger >> nompararecup;
													 j.ajout_descr_para(nomentreesrecup, nompararecup); }


                fichiercharger.close();
          
        }
        else
               { cout << "Impossible d'ouvrir le fichier !" << endl;}
               
               
	 }
	 
	 }

	//affichage de la Feuille de Personnage et du Journal
	v.affiche_vous();
	j.affiche_entrees();


	string descr="ligne vide";

	int* tab=new int[100]; 	// tableau pour éviter de répéter l'inscription dans le journal quand le paragraphe est déjà visité
	for (int k=0;k<100;k++) {tab[k]=-1;}
	int lastpara=0;

	//lancement de la boucle permettant de naviguer entre les paragraphes
	while (para <= 100 || para == 200 || para == 201 || para == 202 || para == 203 || para == 199 || para == 204 || para == 300)
	 {

		if (para <= 100 && para !=8)
        {
		
		AfficherTexte* aff1=new AfficherTexte(); //affichage du texte du paragraohe
        aff1->affichetxt(paragraphe[para]);
        aff1->show();
        app.exec();
        aff1->close();

		rescombat resu=combat(v,table_rencontres[para]); //gestion du combat
		v.changer_pv(resu.respv);
		if (resu.dead == 1) {v.ajout_objet(p);}
		if (resu.dead == 0)
			{AfficherTexte* aff1=new AfficherTexte();
			aff1->affichetxt(paragraphe[14]);
			aff1->show();
			app.exec();
			aff1->close();
			exit(1);}

		v.ajout_objet(table_item[para]);	//gestion des objets et armes
		v.changer_arme_equipee(armurerie[para]);}
		
		// PARAGRAPHES SPECIAUX //
		
		if (para == 8) //le bâton (arme) est ajouté avant le combat
		{ AfficherTexte* aff1=new AfficherTexte();
        aff1->affichetxt(paragraphe[para]);
        aff1->show();
        app.exec();
        aff1->close();
        
        v.changer_arme_equipee(armurerie[para]);

		rescombat resu=combat(v,table_rencontres[para]);
		v.changer_pv(resu.respv);
		if (resu.dead == 1) {v.ajout_objet(p);}
		if (resu.dead == 0)
			{AfficherTexte* aff1=new AfficherTexte();
			aff1->affichetxt(paragraphe[14]);
			aff1->show();
			app.exec();
			aff1->close();
			exit(1);}

		v.ajout_objet(table_item[para]); }


		if (para == 300) //menu des actions
			{ 
			AfficherMenu* aff=new AfficherMenu();
			para=aff->ouvrirMenu();
			}

		if (para == 201)
	  {	
		  cout<<"Décrivez le paragraphe en un mot :"<<endl;	// Journal : vous créez ou remplacez une entrée
		  cin>>descr;
		  j.ajout_descr_para(descr,lastpara);
		  j.affiche_entrees();

	  }
	  
	  if (para == 202) { j.affiche_entrees(); } //affiche Journal
	  
	  if (para == 203) { v.affiche_vous(); } //affiche Feuille de Personnage

	  if (para == 10) //lancer de dé suite à l'accident
	  {
		  
		AfficherDe* aff2=new AfficherDe();
		aff2->affichede();
        aff2->show();
        app.exec();
        aff2->close();
        
		 int tmp=lancer_de();
		 
		 cout<<"Vous perdez "<<tmp<<" Points de Vie"<<endl;
		 int newpv = v.get_pv()-tmp;
		 if (newpv<0) {cout<<"VOUS êtes mort !"<<endl; 
		 AfficherTexte* aff1=new AfficherTexte();
		  aff1->affichetxt(paragraphe[14]);
		  aff1->show();
		  app.exec();
		  aff1->close();
		  exit(1);}
		 v.changer_pv(newpv);
		 v.affiche_vous();
	  }
	  
	  // à la suite, divers ajouts/retraits d'objets selon les besoins
	  
	  if (para == 3)
	  {		v.ajout_objet(p);
			v.ajout_objet(p);
			v.ajout_objet(p);
			v.affiche_vous();   }
			
	  if (para == 64)
	  {	  v.erase_tab("Croc_empoisonné");
		  v.affiche_vous();
		  }
		
	  if (para == 80)
	  {	  v.erase_tab("Antidote"); }
		  
	  if (para == 52)
	  {	  
		  AfficherTexte* aff1=new AfficherTexte();
		  aff1->affichetxt(paragraphe[14]);
		  aff1->show();
		  app.exec();
		  aff1->close();
		  exit(1); }
		  
	  if (para == 78)
	  {	  v.erase_tab("Essence_nocturne");	 }
		  
	  if (para == 89)
	  {	  v.erase_tab("Corde");	}
	  
	  if (para == 90)
	  {	  v.erase_tab("Miroir");
	      v.ajout_objet(o3);	}
	  
	  if (para == 42)
	  {		v.erase_tab("Coupe_en_Or");
		    v.ajout_objet(p);
			v.ajout_objet(p);
			v.ajout_objet(p);
			v.affiche_vous();   }
			
	if (para == 81)
	  {	  v.erase_tab("Pierre_solaire");
	      v.ajout_objet(o7);  }
	  
	  if (para == 68) //trois lancers pour récupérer Notung Junior
	  {
		  int deg=0;
		  for (int i=0;i<3;i++)
		  { 

			AfficherDe* aff2=new AfficherDe();
			aff2->affichede();
			aff2->show();
			app.exec();
			aff2->close();
			
		    int tmp=lancer_de();
		    cout<<"Résutat du lancer "<<i+1<<" : "<<tmp<<endl;
		    if (deg<tmp) {deg=tmp;}
			
		    
		   }
			
			arme n=arme();
			n.changer_arme("Notung Junior",deg);
			v.changer_arme_equipee(n);
			v.affiche_vous();
	   }
	   
	   
	   if (para == 84) //un lancer pour éviter la fosse remplie de piques
	  {
		 
		 AfficherDe* aff2=new AfficherDe();
			aff2->affichede();
			aff2->show();
			app.exec();
			aff2->close();
		 
		 int tmp=lancer_de();
		 cout<<" Résultat du lancer : "<<tmp<<endl;
		 
		 if (tmp < 5)
		  { AfficherTexte* aff1=new AfficherTexte();
			aff1->affichetxt(paragraphe[14]);
			aff1->show();
			app.exec();
			aff1->close();
			exit(1); }
		 
		 
	  }
		    
			
		cout<<endl;

		if (para <= 101) {lastpara=para;} //une astuce pour ne pas compter comme "dernier paragraphe visité" les paragraphes spéciaux (sauvegarde, chargement, etc...)
		
		if (para == 204) //ré-afficher le texte du dernier paragraphe visité
			{ AfficherTexte* aff2=new AfficherTexte();
			aff2->affichetxt(paragraphe[lastpara]);
			aff2->show();
			app.exec();
			aff2->close();}
	   
        
        if (para == 14) //mort -> fin du jeu
		{ exit(1); }
	    
	    
	    if (para == 199) //chargement
        
        {
			AfficherMenu* am3=new AfficherMenu();
			chargerpartie=am3->choisiremplacement();

	 if (chargerpartie==1)
	  {  
		  
		ifstream fichiercharger("sauvegarde1.txt", ios::in);

        if(fichiercharger)
        {
                int pararecup;
                int pvrecup;
                string armerecup;
                int degatsrecup;
                
                int nbobjetsrecup;
                string nomobjetrecup;
                objet objetrecup=objet();
                
                int nbentreesrecup;
                string nomentreesrecup;
                int nompararecup;

                fichiercharger >> pararecup >> pvrecup >> armerecup >> degatsrecup >> nbobjetsrecup;  //on lit jusqu'à l'espace et on stocke ce qui est lu dans la variable indiquée

				para=pararecup;
				v=transcrire_sauvegarde_perso(pvrecup,armerecup,degatsrecup);

				for (int i=0;i<nbobjetsrecup;i++) { fichiercharger >> nomobjetrecup;
													objetrecup.changer_objet(nomobjetrecup);
													v.ajout_objet(objetrecup); }
					
				fichiercharger >> nbentreesrecup;
												
				for (int k=0;k<nbentreesrecup;k++) { fichiercharger >> nomentreesrecup;
													 fichiercharger >> nompararecup;
													 j.ajout_descr_para(nomentreesrecup, nompararecup); }


                fichiercharger.close();
          
        }
        else
               { cout << "Impossible d'ouvrir le fichier !" << endl;}
               
               
	 }

	 if (chargerpartie==2)
	  {  
		  
		ifstream fichiercharger("sauvegarde2.txt", ios::in);

        if(fichiercharger)
        {
                int pararecup;
                int pvrecup;
                string armerecup;
                int degatsrecup;
                
                int nbobjetsrecup;
                string nomobjetrecup;
                objet objetrecup=objet();
                
                int nbentreesrecup;
                string nomentreesrecup;
                int nompararecup;

                fichiercharger >> pararecup >> pvrecup >> armerecup >> degatsrecup >> nbobjetsrecup;  //on lit jusqu'à l'espace et on stocke ce qui est lu dans la variable indiquée

				para=pararecup;
				v=transcrire_sauvegarde_perso(pvrecup,armerecup,degatsrecup);

				for (int i=0;i<nbobjetsrecup;i++) { fichiercharger >> nomobjetrecup;
													objetrecup.changer_objet(nomobjetrecup);
													v.ajout_objet(objetrecup); }
					
				fichiercharger >> nbentreesrecup;
												
				for (int k=0;k<nbentreesrecup;k++) { fichiercharger >> nomentreesrecup;
													 fichiercharger >> nompararecup;
													 j.ajout_descr_para(nomentreesrecup, nompararecup); }


                fichiercharger.close();
          
        }
        else
               { cout << "Impossible d'ouvrir le fichier !" << endl;}
               
               
	 }
	 
	 
	if (chargerpartie==3)
	  {  
		  
		ifstream fichiercharger("sauvegarde3.txt", ios::in);

        if(fichiercharger)
        {
                int pararecup;
                int pvrecup;
                string armerecup;
                int degatsrecup;
                
                int nbobjetsrecup;
                string nomobjetrecup;
                objet objetrecup=objet();
                
                int nbentreesrecup;
                string nomentreesrecup;
                int nompararecup;

                fichiercharger >> pararecup >> pvrecup >> armerecup >> degatsrecup >> nbobjetsrecup;  //on lit jusqu'à l'espace et on stocke ce qui est lu dans la variable indiquée

				para=pararecup;
				v=transcrire_sauvegarde_perso(pvrecup,armerecup,degatsrecup);

				for (int i=0;i<nbobjetsrecup;i++) { fichiercharger >> nomobjetrecup;
													objetrecup.changer_objet(nomobjetrecup);
													v.ajout_objet(objetrecup); }
					
				fichiercharger >> nbentreesrecup;
												
				for (int k=0;k<nbentreesrecup;k++) { fichiercharger >> nomentreesrecup;
													 fichiercharger >> nompararecup;
													 j.ajout_descr_para(nomentreesrecup, nompararecup); }


                fichiercharger.close();
          
        }
        else
               { cout << "Impossible d'ouvrir le fichier !" << endl;}
               
               
	 }

		AfficherTexte* aff3=new AfficherTexte();
        aff3->affichetxt(paragraphe[para]);
        aff3->show();
        app.exec();
        aff3->close();
        
		v.affiche_vous();
		j.affiche_entrees();
		
	}   


	int save=0;	 //fonction de sauvegarde

	if (para == 200)

	{
		AfficherMenu* am4=new AfficherMenu();
		save=am4->choisiremplacement();
		
	if (save==1)
	 { ofstream fichierecr("sauvegarde1.txt", ios::out | ios::trunc);

        if(fichierecr)
        {	
			

                fichierecr << lastpara << endl;
                fichierecr << v.get_pv() <<endl;
                fichierecr << (v.get_armeequip()).get_nom_objet() << endl;
                fichierecr << (v.get_armeequip()).get_degats() << endl;
                fichierecr << v.get_nb_objets() << endl;

                for (int i=0;i<100;i++) { if ((v.get_tab(i)).get_nom_objet() != "vide")
											{ fichierecr << (v.get_tab(i)).get_nom_objet() <<endl; } }
											
				fichierecr << j.get_nb_entrees() << endl;
				
				for (int k=0;k<100;k++) { if (j.get_descr(k) != "ligne vide")
											{ fichierecr << j.get_descr(k) <<endl;
											  fichierecr << j.get_para_asso(k) <<endl; } }

                fichierecr.close();
        }
        else
                cout << "Impossible d'ouvrir le fichier !" << endl;


	}

	if (save==2)
	 { ofstream fichierecr("sauvegarde2.txt", ios::out | ios::trunc);

        if(fichierecr)
        {	
			

                fichierecr << lastpara << endl;
                fichierecr << v.get_pv() <<endl;
                fichierecr << (v.get_armeequip()).get_nom_objet() << endl;
                fichierecr << (v.get_armeequip()).get_degats() << endl;
                fichierecr << v.get_nb_objets() << endl;

                for (int i=0;i<100;i++) { if ((v.get_tab(i)).get_nom_objet() != "vide")
											{ fichierecr << (v.get_tab(i)).get_nom_objet() <<endl; } }
											
				fichierecr << j.get_nb_entrees() << endl;
				
				for (int k=0;k<100;k++) { if (j.get_descr(k) != "ligne vide")
											{ fichierecr << j.get_descr(k) <<endl;
											  fichierecr << j.get_para_asso(k) <<endl; } }

                fichierecr.close();
        }
        else
                cout << "Impossible d'ouvrir le fichier !" << endl;


	}
	
	
	if (save==3)
	 { ofstream fichierecr("sauvegarde3.txt", ios::out | ios::trunc);

        if(fichierecr)
        {	
			

                fichierecr << lastpara << endl;
                fichierecr << v.get_pv() <<endl;
                fichierecr << (v.get_armeequip()).get_nom_objet() << endl;
                fichierecr << (v.get_armeequip()).get_degats() << endl;
                fichierecr << v.get_nb_objets() << endl;

                for (int i=0;i<100;i++) { if ((v.get_tab(i)).get_nom_objet() != "vide")
											{ fichierecr << (v.get_tab(i)).get_nom_objet() <<endl; } }
											
				fichierecr << j.get_nb_entrees() << endl;
				
				for (int k=0;k<100;k++) { if (j.get_descr(k) != "ligne vide")
											{ fichierecr << j.get_descr(k) <<endl;
											  fichierecr << j.get_para_asso(k) <<endl; } }

                fichierecr.close();
        }
        else
                cout << "Impossible d'ouvrir le fichier !" << endl;


	}


 }
 
		cout<<"Allez au paragraphe suivant :"<<endl; //la boucle propose de choisir le paragraphe sur lequel on sera renvoyé
	    cin>>para;
	    cout<<endl;
 
}

		if (para == 101) //spécial : le dernier paragraphe met fin à l'Aventure, il ne se termine pas par un cin
        {AfficherTexte* aff4=new AfficherTexte();
        aff4->affichetxt(paragraphe[para]);
        aff4->show();
        app.exec();
        aff4->close();}
       
        



cout<<"	FIN DU JEU	"<<endl;
cout<<endl;



return 0;

}
