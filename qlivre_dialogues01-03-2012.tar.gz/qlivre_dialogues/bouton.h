#ifndef BOUTON_H
#define BOUTON_H

#include <QPushButton>

class Bouton : public QPushButton
{
    Q_OBJECT
public:
    explicit Bouton(const QString &text , int valeur = 0 , QWidget *parent = 0 );
    explicit Bouton(const QString &text , int posX , int posY , int valeur = 0 , QWidget *parent = 0);
signals:

public slots:
    void setValeur (int valeur);
    int valeur () const;
    int x() const;
    int y() const;
    void setX (int x);
    void setY (int y);

private:
    int m_x;
    int m_y;
    int m_valeur;
};

#endif // BOUTON_H
