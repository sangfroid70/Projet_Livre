#include "tableauchiffres.h"

TableauChiffres::TableauChiffres(QVector<int> const& chiffres , QWidget *parent) :
    QWidget(parent) ,
    m_chiffres (chiffres) ,
    m_total (0)
{
    for (int i = 0 ; i < m_chiffres.size() ; i++) {
        m_total += m_chiffres[i];
    }

    layout = new QHBoxLayout;
    setLayout(layout);
}

void TableauChiffres::chiffresLCD () {
    for(int i = 0 ; i < m_chiffres.size() ; i ++) {
        ecransLCD << new QLCDNumber(1);
        ecransLCD[i]->display(m_chiffres[i]);
        layout->addWidget(ecransLCD[i]);
    }
}

void TableauChiffres::totalLCD() {
    ecransLCD << new QLCDNumber(2);
    ecransLCD.last()->display(total());
    layout->addWidget(ecransLCD.last());
}

void TableauChiffres::toutLCD () {
    chiffresLCD();
    layout->addWidget(new QLabel(" = " , this));
    totalLCD();
}

int TableauChiffres::total () {
    return m_total;
}

void TableauChiffres::totalLabel () {
    ecransLabel << new QLabel (QString::number(total()));
    layout->addWidget(ecransLabel.last());
}

void TableauChiffres::toutLabel () {
    chiffresLabel();
    layout->addWidget(new QLabel(" = " , this));
    totalLabel();
}

void TableauChiffres::chiffresLabel() {
    for (int i = 0 ; i < m_chiffres.size() ; i++) {
        ecransLabel << new QLabel (QString::number(m_chiffres[i]));
        layout->addWidget(ecransLabel[i]);
        if (i+1 < m_chiffres.size()) {
            layout->addWidget(new QLabel(" + " , this));
        }
    }
}

void TableauChiffres::clear () {
    ecransLabel.clear();
    ecransLCD.clear();
}
