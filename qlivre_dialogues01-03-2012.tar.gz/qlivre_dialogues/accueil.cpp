#include "accueil.h"

Accueil::Accueil(QWidget *parent) :
    QDialog(parent) ,
    m_ligne (-1)
{
    setMinimumSize(300,200);

    mapper = new QSignalMapper();

    QTabWidget *onglets = new QTabWidget();

    layoutPageNouveau = new QGridLayout;
    QGroupBox *pageNouveau = new QGroupBox ("Nouvelle partie" , this);
    onglets->addTab(pageNouveau , "Nouveau");

    afficherLigneEdit("Nom du h�ros" , "nom du h�ros");
    afficherLigneConfig("Vie" , 3);
    afficherLigneConfig("Attaque" , 2);
    afficherLigneConfig("Magie" , 4);

    pageNouveau->setLayout(layoutPageNouveau);

    boutonsDialogue = new QDialogButtonBox (QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
    QHBoxLayout *layoutBoutons = new QHBoxLayout;
    layoutBoutons->addStretch(1);
    layoutBoutons->addWidget (boutonsDialogue);

    layout = new QVBoxLayout;
    layout->addWidget (onglets);
    layout->addLayout(layoutBoutons);

    setLayout(layout);

    connect (boutonsDialogue , SIGNAL(accepted()) , this , SLOT (accepter()));
    connect (boutonsDialogue , SIGNAL(rejected()) , this , SLOT (reject()));
    QObject::connect(mapper , SIGNAL(mapped(QWidget*)) , this , SLOT (lancer(QWidget*)));
    QObject::connect(mapper , SIGNAL(mapped(int)) , this , SLOT (checkText(int)));

}

void Accueil::accepter () {    
    int taille =  check.size();
    int nbChecked (0);
    for (int i = 0 ; i < taille ; i++) {
        if (check[i]->checkState() == Qt::Checked) {
            nbChecked++;
        }
    }
    if (nbChecked == taille) {
        accept ();
    }
}

void Accueil::lancer (QWidget *widget) {
    Bouton *bouton = (Bouton*) widget;
    int ligne (bouton->y());
    ModuleDes monDeDeTest (bouton->valeur());
    if (monDeDeTest.exec() == QDialog::Accepted) {
        TableauChiffres *monTableau = new TableauChiffres (monDeDeTest.resultats());
        monTableau->toutLabel();
        QCheckBox *checkbox = (QCheckBox*) layoutPageNouveau->itemAtPosition(ligne , 2)->widget();
        checkbox->setChecked(true);
        delete bouton;
        layoutPageNouveau->addWidget(monTableau , ligne , 1);
    }
}

void Accueil::afficherLigneEdit (QString intitule , QString aide) {
    m_ligne++;
    lineEditNomJoueur = new QLineEdit;
    lineEditNomJoueur->setPlaceholderText(aide);
    layoutPageNouveau->addWidget(new QLabel(intitule , this) , m_ligne , 0);
    layoutPageNouveau->addWidget(lineEditNomJoueur , m_ligne , 1);
    addCheckBox (m_ligne);
    mapper->setMapping(lineEditNomJoueur , m_ligne);
    QObject::connect(lineEditNomJoueur , SIGNAL (textChanged(QString)) , mapper  , SLOT (map()));
}

void Accueil::afficherLigneConfig(QString intitule, int nombreDes) {
    int index;
    m_ligne++;
    boutonsLancer << new Bouton ("Lancer" , 1 , m_ligne , nombreDes , this);
    index = boutonsLancer.indexOf(boutonsLancer.last());

    mapper->setMapping(boutonsLancer[index] , boutonsLancer[index]);
    QString singulierPluriel ((nombreDes==1)?" d�)":" d�s)");
    intitule += " (" + QString::number(nombreDes) + singulierPluriel;
    layoutPageNouveau->addWidget(new QLabel(intitule , this) , m_ligne , 0 , Qt::AlignTop);
    layoutPageNouveau->addWidget(boutonsLancer[index] , m_ligne , 1);
    addCheckBox(m_ligne);
    QObject::connect (boutonsLancer[index] , SIGNAL (clicked()) , mapper , SLOT (map()));
}

void Accueil::addCheckBox(int ligne) {
    check << new QCheckBox (this);
    check.last()->setChecked(false);
    check.last()->setDisabled(true);
    layoutPageNouveau->addWidget(check.last() , ligne , 2);
}

void Accueil::checkText (int ligne) {
    qDebug () << ligne;
    if (lineEditNomJoueur->text () !="") {
        check[ligne]->setChecked(true);
    } else check[ligne]->setChecked(false);
}

