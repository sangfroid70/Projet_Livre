#ifndef TABLEAUCHIFFRES_H
#define TABLEAUCHIFFRES_H

#include <QWidget>
#include <QHBoxLayout>
#include <QLCDNumber>
#include <QLabel>
#include <QVector>

class TableauChiffres : public QWidget
{
    Q_OBJECT
public:
    explicit TableauChiffres(QVector<int> const& chiffres , QWidget *parent = 0);
    void chiffresLCD();
    void totalLCD ();
    void toutLCD ();
    void totalLabel ();
    void toutLabel ();
    void chiffresLabel ();
    int total();
    void clear ();

signals:

public slots:

private:
    QHBoxLayout *layout;
    QVector<int> m_chiffres;
    QVector<QLCDNumber*> ecransLCD;
    QVector<QLabel*> ecransLabel;
    int m_total;

};

#endif // TableauChiffres_H
