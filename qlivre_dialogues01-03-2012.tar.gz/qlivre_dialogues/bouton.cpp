#include "bouton.h"

Bouton::Bouton (const QString &text, int valeur, QWidget *parent) :
    QPushButton(text , parent) ,
    m_x (0) ,
    m_y (0) ,
    m_valeur (valeur)
{

}

Bouton::Bouton (const QString &text, int posX, int posY, int valeur, QWidget *parent) :
    QPushButton(text , parent) ,
    m_x (posX) ,
    m_y (posY) ,
    m_valeur (valeur)
{

}

/////////// Setters ///////////
void Bouton::setValeur (int valeur) {
    m_valeur = valeur;
}

void Bouton::setX (int x) {
    m_x = x;
}

void Bouton::setY (int y) {
    m_y = y;
}

////////////// Getters ////////////
int Bouton::valeur() const {
    return m_valeur;
}

int Bouton::x() const {
    return m_x;
}

int Bouton::y() const{
    return m_y;
}
