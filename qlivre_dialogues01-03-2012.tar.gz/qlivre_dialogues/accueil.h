#ifndef ACCUEIL_H
#define ACCUEIL_H

#include <QDialog>
#include <QObject>
#include <QDialogButtonBox>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QGroupBox>
#include <QLineEdit>
#include <QCheckBox>
#include <QLabel>
#include <QTabWidget>
#include "personnage.h"
#include "moduledes.h"
#include "tableauchiffres.h"
#include <QSignalMapper>
#include "bouton.h"

class Accueil : public QDialog
{
    Q_OBJECT
public:
    explicit Accueil(QWidget *parent = 0);

signals:

public slots:
    void accepter ();
    void lancer (QWidget *widget);
    void checkText (int ligne);

private:
    int m_ligne;
    QSignalMapper *mapper;
    QGridLayout *layoutPageNouveau;
    QVector<Bouton*> boutonsLancer;
    QVBoxLayout *layout;
    QDialogButtonBox *boutonsDialogue;
    QLineEdit *lineEditNomJoueur;
    QVector<QCheckBox*> check;


    void afficherLigneConfig (QString intitule , int nombreDes);
    void afficherLigneEdit (QString intitule , QString aide);
    void addCheckBox (int ligne);

};

#endif // ACCUEIL_H
