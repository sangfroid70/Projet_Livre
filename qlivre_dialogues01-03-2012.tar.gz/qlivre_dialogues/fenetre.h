#ifndef FENETRE_H
#define FENETRE_H

#include <QApplication>
#include <QtGui/QMainWindow>
#include <QMessageBox>
#include <QAction>
#include <QMenuBar>
#include <QMenu>
#include "moteur.h"
#include "accueil.h"

class Fenetre : public QMainWindow
{
    Q_OBJECT

public:
    Fenetre(QWidget *parent = 0);
    ~Fenetre();

public slots :
    void nouveauJeu ();
    void ouvrirJeu ();
    void enregistrerJeu ();
    void aPropos ();

private:
    void creerMenus ();
    void creerActions ();

    QAction *actionAPropos;
    QAction *actionAProposQt;
    QAction *actionNouveau;
    QAction *actionOuvrir;
    QAction *actionEnregistrer;
    QAction *actionQuitter;


};

#endif // FENETRE_H
