#include "moteur.h"

Moteur::Moteur(QObject *parent) :
    QObject(parent)
{
}

Moteur::~Moteur {

}
